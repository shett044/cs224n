# NMT Assignment

Create virtual environment
```bash
conda env create --file local_env.yml
```

Activate and deactivate enviroment
```bash
conda activate local_nmt
conda deactivate
```

Install necessary packages (On your VM)
```bash
pip install -r gpu_requirements.txt
```
